package assignment2_1;

abstract public class Employee {
	
	protected String empId;
	protected String empName;
	protected double baseSalary;
	
	public Employee(String empId,String empName,double baseSalary) {
		this.empId = empId;
		this.empName = empName;
		this.baseSalary = baseSalary;
	}
	
	public Employee(String empId,String empName) {
		this.empId = empId;
		this.empName = empName;
	}
	
	public String getEmpId() {
		return empId;
	}
	
	public String getEmpName() {
		return empName;
	}
	
	public double getBaseSalary() {
		return baseSalary;
	}
	
	public abstract double calculateSalary();

}
