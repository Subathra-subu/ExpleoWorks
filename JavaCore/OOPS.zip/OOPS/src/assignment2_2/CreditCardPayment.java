package assignment2_2;

import java.time.LocalDate;
public class CreditCardPayment extends Payment {
	
	private String cardNumber;
	private String cvv;
	private LocalDate expiryDate;
	

	public CreditCardPayment(String transactionId, double amount, String cutomerName, String cardNumber,
			String cvv,LocalDate expiryDate) {
		super(transactionId, amount, cutomerName);
		this.cardNumber = cardNumber;
		this.cvv = cvv;
		this.expiryDate = expiryDate;
	}


	public String getCardNumber() {
		return cardNumber;
	}


	public void setCardNumber(String cardNumber) {
		this.cardNumber = cardNumber;
	}


	public String getCvv() {
		return cvv;
	}


	public void setCvv(String cvv) {
		this.cvv = cvv;
	}


	public LocalDate getExpiryDate() {
		return expiryDate;
	}


	public void setExpiryDate(LocalDate expiryDate) {
		this.expiryDate = expiryDate;
	}

	public boolean validatePayment() {
		
		boolean validCard = cardNumber.length() == 16;
	    boolean validCvv = cvv.length() == 3;
	    boolean isExpiry = LocalDate.now().isAfter(expiryDate);

	    return validCard && validCvv && isExpiry;
		
		
	}
	
	public boolean processPayment() {
		
		return false;
	}

}
