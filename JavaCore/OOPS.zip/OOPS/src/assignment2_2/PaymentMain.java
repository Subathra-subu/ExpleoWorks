package assignment2_2;

import java.time.LocalDate;

import java.util.Scanner;

class PaymentMain{
	
	static Scanner scanner = new Scanner(System.in);
	
	public static String toGetTransactionId() {
		System.out.println("Enter the Transaction id:");
		String transactionId = scanner.next();
		return transactionId;
	}
	
	public static double toGetAmount() {
		System.out.println("Enter the amount:");
		double amount = scanner.nextDouble();
		return amount;
	}
	
	public static String toGetCustomerName() {
		System.out.println("Enter the Customer Name:");
		String customerName = scanner.next();
		return customerName;
	}

	public static void main(String[] args) {
		
		Payment payment = null;
		
		int choice;
		
		do {
			
		System.out.println("\nThe payment options are :\n 1. Credit card payment"
				+ "\n 2. Net banking payment"
				+ "\n 3. UPI payment"
				+ "\n 4. Exit");
		
		System.out.println("Enter the choice:");
		choice = scanner.nextInt();
		
		if(choice==4) {
			System.out.println("Thank you");
		}
		
		String transactionId= PaymentMain.toGetTransactionId();
		double amount = PaymentMain.toGetAmount();
		String customerName = PaymentMain.toGetCustomerName();
		
		switch(choice) {
		
		case 1:
				
				System.out.println("Enter the Cardnumber:");
				String cardnumber = scanner.next();
				
				System.out.println("Enter the cvv:");
				String ccv = scanner.next();
				
				System.out.println("Enter the Expiry Date:");
				String date = scanner.next();
				LocalDate expiryDate = LocalDate.parse(date);
				
				payment = new CreditCardPayment(transactionId, amount, customerName, cardnumber, ccv, expiryDate);
				payment.executeTransaction();
				
				break;
				
				
		case 2:
			
				System.out.println("Enter the Bank Name:");
				String bankName = scanner.next();
			
				System.out.println("Enter the AccountNumber:");
				String accountNumber = scanner.next();
			
				System.out.println("Enter the IFSC code:");
				String ifscCode = scanner.next();
				
				payment = new NetBankingPayment(transactionId, amount, customerName, bankName, accountNumber, ifscCode);
				payment.executeTransaction();
				
				break;
				
		case 3:

				System.out.println("Enter the UPI ID:");
				String upiId = scanner.next();
		
				System.out.println("Enter the UPI Pin:");
				String upiPin = scanner.next();
				
				payment = new UPIPayment(transactionId, amount, customerName, upiId, upiPin);
				payment.executeTransaction();
				
				break;
				
		 default:
			 
			 	System.out.println("Invalid option");
			
		}
		}while(choice != 4);
		

	}

}
