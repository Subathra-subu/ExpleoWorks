package handsOn_6__3;

public class Circle extends Shape {
	
	protected double radius = 1.0;

	public Circle() {
		
	}

	public Circle(double radius) {
		this.radius = radius;
	}

	public Circle(double radius,String color, boolean isFilled) {
		super(color, isFilled);
		this.radius = radius;
	}

	public double getRadius() {
		return radius;
	}

	public void setRadius(double radius) {
		this.radius = radius;
	}
	
	public double getArea() {
		return getRadius()*getRadius();
	}
	
	public double getPerimeter() {
		return 2*Math.PI*getRadius();
	}

	@Override
	public String toString() {
		return "Circle [radius=" + getRadius() + ", color=" + getColor() + ", isFilled=" + isFilled() + "]";
	}
	
}
