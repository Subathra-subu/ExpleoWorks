package handsOn_6__3;

public class Square extends Rectangle {

	public Square() {
		
	}
	
	public Square(double size) {
		super(size,size);
	}

	public Square(double width, double length, String color, boolean isFilled) {
		super(width, length, color, isFilled);
	}
	
	public double getSide() {
		return getLength();
	}
	
	public void setLength(double size) {
		setLength(size);
	}
	
	public void setWidth(double size) {
		setWidth(size);
	}

	@Override
	public String toString() {
		return "Square [width=" + getWidth() + ", length=" + getLength() + ", color=" + getColor() + ", isFilled=" + isFilled() + "]";
	}
	
	

}
