package movieBooking;

import java.time.LocalDate;
import java.util.Scanner;


public class MovieBooking extends Catalog{

	public static void main(String[] args) { 
		
		Scanner scanner = new Scanner(System.in);
		
		Catalog catalog = new Catalog();
		
		catalog.addMovie(new Movie("aaa","abc",
				7,"Tamil",
				LocalDate.parse("2025-03-09"),"India",
				"Comedy"));
		
		catalog.addMovie(new Movie("bbb","abc",
				8,"English",
				LocalDate.parse("2025-03-09"),"India",
				"Thriller"));
		
		catalog.addMovie(new Movie("aaa","abc",
				7,"French",
				LocalDate.parse("2025-03-09"),"France",
				"Horror"));

		
//		System.out.println("Enter the Genre to Search:");
//		String genre = scanner.next();
		

		System.out.println("Enter the Title to Search:");
		String title = scanner.next();
		
		//catalog.searchByGenre(genre);
		
		catalog.searchByTitle(title);
		
		scanner.close();

	}

}
