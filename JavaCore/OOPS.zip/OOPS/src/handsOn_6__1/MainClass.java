package handsOn_6__1;

public class MainClass {

	public static void main(String[] args) {
		
		System.out.println("Student Details:");
		
		Student student = new Student("Anu","Salem","XYZ",2020,10000);
		
		System.out.println(student);
		
		System.out.println("Staff Details:");
		
		Staff staff = new Staff("Abi","Salem","ABC School",20000);
		
		System.out.println(staff);

	}

}
