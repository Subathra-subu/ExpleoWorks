package innerClasses;

class OuterClass{
	void display() {
		System.out.println("The method of outer class is called");
	}
	
	class InnerClass{
		void show() {
			System.out.println("The method of inner class is called");
		}
	}
}

public class InnerClassExample {

	public static void main(String[] args) {
		
		OuterClass outerClass = new OuterClass();
		
		outerClass.display();
		
		OuterClass.InnerClass innerClass = outerClass.new InnerClass();
		
		innerClass.show();
		//innerClass.display();
		}

}
