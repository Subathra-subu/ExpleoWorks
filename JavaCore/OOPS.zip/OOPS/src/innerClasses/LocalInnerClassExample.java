package innerClasses;

class Outer{
	
	int value = 28;
	
	public void outerClassMethod() {
		
		System.out.println("Outer class method");
		
		class Inner{
			
			public void innerClassMethod() {
				
				System.out.println("Inner class method");
				
				System.out.println("Value = "+value);
			}
		}
		
		Inner inner = new Inner();
		
		inner.innerClassMethod();
	}
}

public class LocalInnerClassExample {

	public static void main(String[] args) {
		
		Outer outer = new Outer();
		
		outer.outerClassMethod();

	}

}
